// ============================================================
// webhook.gs — รับ Webhook จาก LINE (Approve / Reject)
// ============================================================

// ── Entry point หลัก — LINE ส่ง POST มาที่นี่ ──────────────
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const events = body.events || [];

    events.forEach(event => {
      if (event.type === 'postback') {
        handlePostback(event);
      } else if (event.type === 'message' && event.message.type === 'text') {
        handleTextMessage(event);
      }
    });

  } catch (err) {
    console.error('doPost error:', err.message);
  }

  // LINE ต้องการ 200 OK เสมอ
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ok' }))
    .setMimeType(ContentService.MimeType.JSON);
}

// ── จัดการ Postback (กดปุ่ม Approve/Reject) ─────────────
function handlePostback(event) {
  const data = parseQueryString(event.postback.data);
  const action    = data.action;
  const productId = data.product_id;

  console.log(`Postback: action=${action}, product_id=${productId}`);

  if (!productId) return;

  const rowNum = findRowByProductId(productId);
  if (!rowNum) {
    console.error(`Product not found: ${productId}`);
    return;
  }

  if (action === 'approve') {
    approveProduct(rowNum, productId);
  } else if (action === 'reject') {
    rejectProduct(rowNum, productId);
  }
}

// ── Approve: อัปเดต status แล้วโพสต์เลย ─────────────────
function approveProduct(rowNum, productId) {
  const sheet = getSheet();
  sheet.getRange(rowNum, CONFIG.COL.STATUS).setValue(CONFIG.STATUS.APPROVED);

  console.log(`Approved row ${rowNum}`);

  // โพสต์ทันทีหลัง Approve
  try {
    postApprovedProduct(rowNum);
  } catch (e) {
    logError(rowNum, `Post failed: ${e.message}`);
    sendLineText(`❌ โพสต์ไม่สำเร็จ\n\nสินค้า: row ${rowNum}\nError: ${e.message}`);
  }
}

// ── Reject: อัปเดต status ────────────────────────────────
function rejectProduct(rowNum, productId) {
  const sheet = getSheet();
  sheet.getRange(rowNum, CONFIG.COL.STATUS).setValue(CONFIG.STATUS.REJECTED);

  const productName = sheet.getRange(rowNum, CONFIG.COL.PRODUCT_NAME).getValue();
  sendLineText(`🚫 Rejected แล้ว\n\n📦 ${productName}\n\nแก้ไขข้อมูลใน Sheets แล้วเปลี่ยน Status กลับเป็น PENDING เพื่อส่งใหม่`);
  console.log(`Rejected row ${rowNum}`);
}

// ── หา Row Number จาก product_id ─────────────────────────
function findRowByProductId(productId) {
  const sheet = getSheet();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return null;

  const ids = sheet.getRange(2, CONFIG.COL.PRODUCT_ID, lastRow - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(productId)) {
      return i + 2;
    }
  }
  return null;
}

// ── Parse query string เป็น object ───────────────────────
function parseQueryString(str) {
  const result = {};
  str.split('&').forEach(pair => {
    const [key, val] = pair.split('=');
    if (key) result[decodeURIComponent(key)] = decodeURIComponent(val || '');
  });
  return result;
}

// ── Handle ข้อความธรรมดาจาก LINE ─────────────────────────
function handleTextMessage(event) {
  const text = event.message.text.toLowerCase().trim();
  if (text === 'status' || text === 'สถานะ') {
    sendStatusSummary();
  }
}

// ── ส่งสรุปสถานะทั้งหมดไป LINE ──────────────────────────
function sendStatusSummary() {
  const sheet = getSheet();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) {
    sendLineText('ยังไม่มีข้อมูลสินค้าใน Sheets ครับ');
    return;
  }

  const data = sheet.getRange(2, 1, lastRow - 1, CONFIG.COL.STATUS).getValues();
  const counts = {};
  Object.values(CONFIG.STATUS).forEach(s => counts[s] = 0);

  data.forEach(row => {
    const s = row[CONFIG.COL.STATUS - 1];
    if (counts[s] !== undefined) counts[s]++;
  });

  const msg = `📊 สรุปสถานะสินค้า\n\n` +
    `⏳ PENDING: ${counts.PENDING}\n` +
    `🤖 AI_DONE: ${counts.AI_DONE}\n` +
    `👀 รอ Review: ${counts.PENDING_REVIEW}\n` +
    `✅ Approved: ${counts.APPROVED}\n` +
    `❌ Rejected: ${counts.REJECTED}\n` +
    `🚀 Posted: ${counts.POSTED}\n` +
    `🔴 Error: ${counts.ERROR}`;

  sendLineText(msg);
}

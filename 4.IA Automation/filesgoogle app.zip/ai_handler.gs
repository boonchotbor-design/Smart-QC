// ============================================================
// ai_handler.gs — เรียก Gemini API เพื่อเขียนแคปชัน
// ============================================================

function generateCaption(productName, keyFeatures, affiliateLink, extraNotes) {
  const prompt = `คุณคือผู้เชี่ยวชาญด้านการเขียน Copy ขายสินค้าออนไลน์สำหรับคนไทย

เขียนแคปชันขายสินค้าสำหรับ Facebook และ TikTok โดยใช้ข้อมูลต่อไปนี้:

ชื่อสินค้า: ${productName}
จุดเด่น: ${keyFeatures}
ลิงก์ซื้อ: ${affiliateLink}
โน้ตพิเศษ: ${extraNotes || 'ไม่มี'}

กฎการเขียน:
1. ขึ้นต้นด้วย Hook ดึงดูดความสนใจ พร้อม Emoji
2. เล่าจุดเด่นสินค้า 3-4 ข้อ แบบเป็นธรรมชาติ ไม่ขายของจ๋า
3. ใส่ Social Proof หรือ Urgency เช่น "ขายดีมาก" หรือ "เหลือน้อยแล้ว"
4. CTA ชัดเจน พร้อมลิงก์ที่ให้มา
5. Hashtag 5-8 อัน เหมาะกับสินค้านั้นๆ
6. ความยาว 150-250 คำ
7. ภาษาไทยเป็นกันเอง เหมาะกับ Gen Z และ Millennials

ตอบเฉพาะแคปชันเท่านั้น ไม่ต้องมีคำอธิบายหรือหัวข้อ`;

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${CONFIG.GEMINI_MODEL}:generateContent?key=${CONFIG.GEMINI_API_KEY}`;

  const payload = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.8,
      maxOutputTokens: 1024
    }
  };

  const options = {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  try {
    const response = UrlFetchApp.fetch(url, options);
    const json = JSON.parse(response.getContentText());

    if (response.getResponseCode() !== 200) {
      throw new Error(`Gemini API Error: ${json.error?.message || response.getContentText()}`);
    }

    return json.candidates[0].content.parts[0].text.trim();

  } catch (e) {
    throw new Error(`generateCaption failed: ${e.message}`);
  }
}

// ── รันแคปชันสำหรับทุกแถวที่เป็น PENDING ─────────────────
function processAllPending() {
  const sheet = getSheet();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  const data = sheet.getRange(2, 1, lastRow - 1, CONFIG.COL.ERROR_LOG).getValues();

  data.forEach((row, i) => {
    const rowNum = i + 2;
    const status = row[CONFIG.COL.STATUS - 1];
    if (status !== CONFIG.STATUS.PENDING) return;

    const productName    = row[CONFIG.COL.PRODUCT_NAME - 1];
    const keyFeatures    = row[CONFIG.COL.KEY_FEATURES - 1];
    const affiliateLink  = row[CONFIG.COL.AFFILIATE_LINK - 1];
    const extraNotes     = row[CONFIG.COL.EXTRA_NOTES - 1];

    if (!productName) {
      logError(rowNum, 'ไม่มีชื่อสินค้า');
      return;
    }

    try {
      console.log(`Processing row ${rowNum}: ${productName}`);
      const caption = generateCaption(productName, keyFeatures, affiliateLink, extraNotes);

      sheet.getRange(rowNum, CONFIG.COL.AI_CAPTION).setValue(caption);
      sheet.getRange(rowNum, CONFIG.COL.AI_GENERATED_AT).setValue(new Date().toISOString());
      sheet.getRange(rowNum, CONFIG.COL.STATUS).setValue(CONFIG.STATUS.AI_DONE);

      // ส่ง LINE ทันทีหลัง AI เขียนเสร็จ
      const mediaUrl      = row[CONFIG.COL.MEDIA_URL - 1];
      const productId     = row[CONFIG.COL.PRODUCT_ID - 1];
      const targetPlatform = row[CONFIG.COL.TARGET_PLATFORM - 1];

      const msgId = sendLineFlexMessage(productId, productName, caption, mediaUrl, affiliateLink, targetPlatform);

      sheet.getRange(rowNum, CONFIG.COL.LINE_MSG_ID).setValue(msgId);
      sheet.getRange(rowNum, CONFIG.COL.STATUS).setValue(CONFIG.STATUS.PENDING_REVIEW);

      console.log(`Row ${rowNum} done — LINE message sent`);
      Utilities.sleep(2000); // หน่วง 2 วิ ป้องกัน rate limit

    } catch (e) {
      logError(rowNum, e.message);
    }
  });
}

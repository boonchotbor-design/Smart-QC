// ============================================================
// main.gs — ระบบ Queue, Trigger และ Entry Points หลัก
// ============================================================

// ── Entry Point: รันทุก 6 ชั่วโมง (ตั้ง Trigger ใน GAS) ──
function runEvery6Hours() {
  console.log('=== runEvery6Hours started ===');
  processAllPending();
  console.log('=== runEvery6Hours finished ===');
}

// ── โพสต์สินค้าที่ Approved แล้ว ─────────────────────────
// (ถูกเรียกจาก webhook.gs ทันทีเมื่อกด Approve)
function postApprovedProduct(rowNum) {
  const sheet = getSheet();
  const row = sheet.getRange(rowNum, 1, 1, CONFIG.COL.ERROR_LOG).getValues()[0];

  const productId      = row[CONFIG.COL.PRODUCT_ID - 1];
  const productName    = row[CONFIG.COL.PRODUCT_NAME - 1];
  const mediaUrl       = row[CONFIG.COL.MEDIA_URL - 1];
  const mediaType      = String(row[CONFIG.COL.MEDIA_TYPE - 1]).toUpperCase();
  const affiliateLink  = row[CONFIG.COL.AFFILIATE_LINK - 1];
  const aiCaption      = row[CONFIG.COL.AI_CAPTION - 1];
  const targetPlatform = String(row[CONFIG.COL.TARGET_PLATFORM - 1]).toUpperCase();

  const results = { fb: null, tiktok: null, errors: [] };

  // --- Facebook ---
  if (targetPlatform.includes('FACEBOOK')) {
    try {
      let fbPostId;
      if (mediaType === 'VIDEO') {
        fbPostId = postFacebookVideo(aiCaption, mediaUrl, affiliateLink);
      } else {
        fbPostId = postFacebookImage(aiCaption, mediaUrl, affiliateLink);
      }
      results.fb = fbPostId;
      console.log(`Facebook posted: ${fbPostId}`);
    } catch (e) {
      results.errors.push(`Facebook: ${e.message}`);
      console.error(`Facebook error: ${e.message}`);
    }
  }

  // --- TikTok ---
  if (targetPlatform.includes('TIKTOK')) {
    try {
      if (mediaType === 'VIDEO') {
        const tikTokId = postTikTokVideo(aiCaption, mediaUrl);
        results.tiktok = tikTokId;
        console.log(`TikTok posted: ${tikTokId}`);
      } else {
        results.errors.push('TikTok: รองรับเฉพาะ VIDEO เท่านั้น');
      }
    } catch (e) {
      results.errors.push(`TikTok: ${e.message}`);
      console.error(`TikTok error: ${e.message}`);
    }
  }

  // --- อัปเดต Sheets ---
  const now = new Date().toISOString();
  sheet.getRange(rowNum, CONFIG.COL.POSTED_AT).setValue(now);

  if (results.fb)     sheet.getRange(rowNum, CONFIG.COL.FB_POST_ID).setValue(results.fb);
  if (results.tiktok) sheet.getRange(rowNum, CONFIG.COL.TIKTOK_POST_ID).setValue(results.tiktok);

  if (results.errors.length > 0) {
    sheet.getRange(rowNum, CONFIG.COL.ERROR_LOG).setValue(results.errors.join(' | '));
  }

  const hasAnySuccess = results.fb || results.tiktok;
  sheet.getRange(rowNum, CONFIG.COL.STATUS).setValue(
    hasAnySuccess ? CONFIG.STATUS.POSTED : CONFIG.STATUS.ERROR
  );

  // --- แจ้ง LINE ---
  const platforms = [
    results.fb     ? `📘 FB: fb.com/${results.fb}` : null,
    results.tiktok ? `🎵 TikTok: ${results.tiktok}` : null,
    ...results.errors
  ].filter(Boolean).join('\n');

  const emoji = hasAnySuccess ? '✅' : '❌';
  sendLineText(
    `${emoji} โพสต์ ${hasAnySuccess ? 'สำเร็จ' : 'มีปัญหา'}!\n\n` +
    `📦 ${productName}\n${platforms}\n\n⏰ ${now}`
  );
}

// ── ตั้งค่า Time Trigger อัตโนมัติ ───────────────────────
// รันฟังก์ชันนี้ครั้งเดียวเพื่อสร้าง Trigger
function setupTriggers() {
  // ลบ Trigger เก่าก่อน
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));

  // Trigger ทุก 6 ชั่วโมง
  ScriptApp.newTrigger('runEvery6Hours')
    .timeBased()
    .everyHours(6)
    .create();

  console.log('✅ Trigger ตั้งค่าแล้ว: runEvery6Hours ทุก 6 ชั่วโมง');
  sendLineText('🤖 ระบบ Automation พร้อมใช้งานแล้ว!\n\nTrigger: ทุก 6 ชั่วโมง\nพิมพ์ "status" ใน LINE เพื่อดูสถานะ');
}

// ── ทดสอบระบบ (รันมือเพื่อเช็คว่าทุกอย่างทำงาน) ─────────
function testSystem() {
  console.log('--- Test: LINE ---');
  sendLineText('🧪 ทดสอบระบบ LINE ✅');

  console.log('--- Test: Sheets ---');
  const sheet = getSheet();
  console.log(`Sheet found: ${sheet.getName()}, rows: ${sheet.getLastRow()}`);

  console.log('--- Test: Gemini ---');
  const testCaption = generateCaption(
    'ครีมกันแดด SPF50+',
    'กันน้ำ 80 นาที|เนื้อบางเบา|ไม่ทิ้งคราบขาว',
    'https://example.com',
    'ทดสอบ'
  );
  console.log('Gemini caption:', testCaption.substring(0, 100));

  sendLineText(`🧪 ทดสอบ Gemini ✅\n\nตัวอย่างแคปชัน:\n${testCaption.substring(0, 200)}...`);
  console.log('--- All tests passed ---');
}

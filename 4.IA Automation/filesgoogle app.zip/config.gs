// ============================================================
// config.gs — ตั้งค่า API Keys และค่าคงที่ทั้งหมด
// ============================================================

const CONFIG = {

  // --- Google Sheets ---
  SHEET_ID: 'YOUR_GOOGLE_SHEET_ID',       // ID จาก URL ของ Sheets
  SHEET_NAME: 'Control',                   // ชื่อ Tab

  // --- Gemini API ---
  GEMINI_API_KEY: 'YOUR_GEMINI_API_KEY',  // https://aistudio.google.com/app/apikey
  GEMINI_MODEL: 'gemini-1.5-flash',

  // --- LINE Messaging API ---
  LINE_CHANNEL_TOKEN: 'YOUR_LINE_CHANNEL_ACCESS_TOKEN',
  LINE_USER_ID: 'YOUR_LINE_USER_ID',      // UID ของคุณ (ไม่ใช่ Channel ID)

  // --- Facebook Graph API ---
  FB_PAGE_ID: 'YOUR_FACEBOOK_PAGE_ID',
  FB_PAGE_TOKEN: 'YOUR_FACEBOOK_PAGE_ACCESS_TOKEN',
  FB_API_VERSION: 'v19.0',

  // --- TikTok API ---
  TIKTOK_ACCESS_TOKEN: 'YOUR_TIKTOK_ACCESS_TOKEN',

  // --- คอลัมน์ใน Google Sheets (index เริ่มที่ 1) ---
  COL: {
    PRODUCT_ID:      1,   // A
    PRODUCT_NAME:    2,   // B
    KEY_FEATURES:    3,   // C
    MEDIA_URL:       4,   // D
    MEDIA_TYPE:      5,   // E
    AFFILIATE_LINK:  6,   // F
    TARGET_PLATFORM: 7,   // G
    SCHEDULED_DATE:  8,   // H
    EXTRA_NOTES:     9,   // I
    AI_CAPTION:      10,  // J
    AI_GENERATED_AT: 11,  // K
    STATUS:          12,  // L
    LINE_MSG_ID:     13,  // M
    FB_POST_ID:      14,  // N
    TIKTOK_POST_ID:  15,  // O
    POSTED_AT:       16,  // P
    ERROR_LOG:       17   // Q
  },

  // --- Status Values ---
  STATUS: {
    PENDING:        'PENDING',
    AI_DONE:        'AI_DONE',
    PENDING_REVIEW: 'PENDING_REVIEW',
    APPROVED:       'APPROVED',
    REJECTED:       'REJECTED',
    POSTED:         'POSTED',
    ERROR:          'ERROR'
  }
};

// ── Helper: ดึง Sheet object ──────────────────────────────
function getSheet() {
  return SpreadsheetApp
    .openById(CONFIG.SHEET_ID)
    .getSheetByName(CONFIG.SHEET_NAME);
}

// ── Helper: Log error ลง Sheets ──────────────────────────
function logError(row, message) {
  const sheet = getSheet();
  sheet.getRange(row, CONFIG.COL.STATUS).setValue(CONFIG.STATUS.ERROR);
  sheet.getRange(row, CONFIG.COL.ERROR_LOG).setValue(message);
  console.error(`Row ${row}: ${message}`);
}

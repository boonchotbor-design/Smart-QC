// ============================================================
// fb_handler.gs — โพสต์บน Facebook ผ่าน Graph API
// ============================================================

// ── โพสต์รูปภาพ ───────────────────────────────────────────
function postFacebookImage(caption, imageUrl, affiliateLink) {
  const fullCaption = `${caption}\n\n🛒 สั่งซื้อได้เลย: ${affiliateLink}`;
  const url = `https://graph.facebook.com/${CONFIG.FB_API_VERSION}/${CONFIG.FB_PAGE_ID}/photos`;

  const payload = {
    url:          imageUrl,
    caption:      fullCaption,
    access_token: CONFIG.FB_PAGE_TOKEN
  };

  return callFacebookAPI(url, payload);
}

// ── โพสต์วิดีโอ ────────────────────────────────────────────
function postFacebookVideo(caption, videoUrl, affiliateLink) {
  const fullCaption = `${caption}\n\n🛒 สั่งซื้อได้เลย: ${affiliateLink}`;
  const url = `https://graph.facebook.com/${CONFIG.FB_API_VERSION}/${CONFIG.FB_PAGE_ID}/videos`;

  const payload = {
    file_url:     videoUrl,
    description:  fullCaption,
    access_token: CONFIG.FB_PAGE_TOKEN
  };

  return callFacebookAPI(url, payload);
}

// ── โพสต์ข้อความอย่างเดียว (fallback) ───────────────────
function postFacebookText(caption, affiliateLink) {
  const fullCaption = `${caption}\n\n🛒 สั่งซื้อได้เลย: ${affiliateLink}`;
  const url = `https://graph.facebook.com/${CONFIG.FB_API_VERSION}/${CONFIG.FB_PAGE_ID}/feed`;

  const payload = {
    message:      fullCaption,
    access_token: CONFIG.FB_PAGE_TOKEN
  };

  return callFacebookAPI(url, payload);
}

// ── เรียก Facebook Graph API ─────────────────────────────
function callFacebookAPI(url, payload) {
  const options = {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(url, options);
  const json = JSON.parse(response.getContentText());

  if (response.getResponseCode() !== 200) {
    const errMsg = json.error?.message || response.getContentText();
    throw new Error(`Facebook API Error: ${errMsg}`);
  }

  return json.id || json.post_id || 'unknown';
}

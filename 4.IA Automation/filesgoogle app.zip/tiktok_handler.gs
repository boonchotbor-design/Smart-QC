// ============================================================
// tiktok_handler.gs — โพสต์วิดีโอบน TikTok ผ่าน Content Posting API
// ============================================================

// ── โพสต์วิดีโอจาก URL ────────────────────────────────────
function postTikTokVideo(caption, videoUrl) {
  // Step 1: Init upload
  const initUrl = 'https://open.tiktokapis.com/v2/post/publish/video/init/';

  const initPayload = {
    post_info: {
      title:             caption.substring(0, 150),  // TikTok จำกัด 150 ตัวอักษร
      privacy_level:     'PUBLIC_TO_EVERYONE',
      disable_duet:      false,
      disable_comment:   false,
      disable_stitch:    false,
      video_cover_timestamp_ms: 1000
    },
    source_info: {
      source:    'PULL_FROM_URL',
      video_url: videoUrl
    }
  };

  const initOptions = {
    method: 'post',
    contentType: 'application/json; charset=UTF-8',
    headers: {
      'Authorization': `Bearer ${CONFIG.TIKTOK_ACCESS_TOKEN}`
    },
    payload: JSON.stringify(initPayload),
    muteHttpExceptions: true
  };

  const initResponse = UrlFetchApp.fetch(initUrl, initOptions);
  const initJson = JSON.parse(initResponse.getContentText());

  if (initResponse.getResponseCode() !== 200) {
    throw new Error(`TikTok Init Error: ${JSON.stringify(initJson.error)}`);
  }

  const publishId = initJson.data?.publish_id;
  if (!publishId) {
    throw new Error('TikTok: ไม่ได้รับ publish_id');
  }

  // Step 2: ตรวจสอบสถานะ (poll ไม่เกิน 5 ครั้ง)
  Utilities.sleep(5000);
  const status = checkTikTokPublishStatus(publishId);
  console.log(`TikTok publish status: ${status}`);

  return publishId;
}

// ── เช็คสถานะการโพสต์ TikTok ─────────────────────────────
function checkTikTokPublishStatus(publishId) {
  const url = 'https://open.tiktokapis.com/v2/post/publish/status/fetch/';

  const options = {
    method: 'post',
    contentType: 'application/json; charset=UTF-8',
    headers: {
      'Authorization': `Bearer ${CONFIG.TIKTOK_ACCESS_TOKEN}`
    },
    payload: JSON.stringify({ publish_id: publishId }),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(url, options);
  const json = JSON.parse(response.getContentText());

  return json.data?.status || 'UNKNOWN';
}

# คู่มือติดตั้ง n8n Workflows - ระบบโพสต์สินค้าอัตโนมัติ

## สิ่งที่ต้องเตรียมก่อน

### API Keys / Tokens ที่ต้องมี

| ตัวแปร | วิธีได้มา |
|--------|-----------|
| `SHEET_ID` | URL ของ Google Sheets: docs.google.com/spreadsheets/d/**{ID}**/edit |
| `GEMINI_API_KEY` | https://aistudio.google.com/app/apikey |
| `LINE_USER_ID` | เปิด LINE Developers → Channel → ดู User ID ของตัวเอง |
| `LINE_CHANNEL_TOKEN` | LINE Developers → Messaging API → Channel access token |
| `FB_PAGE_ID` | Facebook Page Settings → About → Page ID |
| `FB_PAGE_TOKEN` | Meta for Developers → Graph API Explorer → Generate Token |
| `TIKTOK_ACCESS_TOKEN` | TikTok for Developers → Content Posting API |

---

## ขั้นตอน Import Workflows

### 1. เข้า n8n Cloud → Workflows → New Workflow
### 2. กด ⋮ (three dots) → Import from File
### 3. Import ตามลำดับ:
   - `workflow_1_ai_caption.json` → ทำงานทุก 6 ชั่วโมง
   - `workflow_2_webhook_approve.json` → รับ Webhook จาก LINE
   - `workflow_3_autopost.json` → โพสต์ทุก 15 นาที

---

## ตั้งค่า Variables ใน n8n

Settings → Variables → เพิ่มตัวแปรทั้งหมดด้านบน

---

## ตั้งค่า Webhook URL สำหรับ LINE

หลัง Import Workflow 2 แล้ว:
1. เปิด Workflow 2 → คลิก node "LINE Webhook"
2. คัดลอก Webhook URL (จะได้รูปแบบ: https://your-instance.app.n8n.cloud/webhook/line-webhook)
3. ไปที่ LINE Developers → Messaging API → Webhook URL → วาง URL นี้
4. กด Verify

---

## การตั้งค่า Credentials ใน n8n

### Google Sheets
- Credentials → New → Google Sheets OAuth2
- เชื่อม Google Account ของคุณ

### LINE
- Credentials → New → LINE OAuth2 API
- ใส่ Channel ID และ Channel Secret

### Gemini
- Credentials → New → Google Gemini API  
- ใส่ API Key

---

## ⚠️ หมายเหตุสำคัญเรื่อง TikTok API

TikTok Content Posting API ต้องสมัครผ่าน:
https://developers.tiktok.com/products/content-posting-api/

ต้องการ:
- Business/Creator Account
- App review จาก TikTok (ใช้เวลา 3-7 วัน)
- Scope: video.publish

ถ้ายังไม่ได้รับ Approval → เปลี่ยน node TikTok ให้เป็น
LINE notification แจ้งให้โพสต์เองก่อนได้

---

## Flow Summary

```
[ทุก 6 ชม.]
Sheets (PENDING) → Gemini เขียนแคปชัน → LINE Flex Message

[กด Approve บน LINE]
Webhook → อัปเดต APPROVED ใน Sheets

[ทุก 15 นาที]
Sheets (APPROVED) → Post Facebook + TikTok → Update POSTED → LINE แจ้งสำเร็จ
```
